// Uncomment the next line to use precompiled headers
//#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset( new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
// is the collection created
ASSERT_TRUE(collection);

// if empty, the size must be 0
ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
// is the collection empty?
ASSERT_TRUE(collection->empty());

// if empty, the size must be 0
ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
FAIL();
}

// Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
// is the collection empty?
    ASSERT_TRUE(collection->empty());
// if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

// is the collection still empty?
    ASSERT_FALSE(collection->empty());
// if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 1);
}

// Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // Get the current size
    int start = collection->size();

    add_entries(5);

    // Test for number of entries is at least 5
    ASSERT_TRUE(collection->size() > 4);
    // Is current size - previous size equal 1
    EXPECT_EQ(collection->size() - start, 5);
}

// Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, IsMaxSizeGreaterThanEntries)
{
    // Get the maximum size of the collection
    int max = collection->max_size();

    //Check that the collection is empty with no entries
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    // Check max against 0
    ASSERT_TRUE(max >= collection->size());

    // Check max against 1
    add_entries(1);
    ASSERT_EQ(collection->size(), 1);
    ASSERT_TRUE(max >= collection->size());

    // Check max against 5
    add_entries(4);
    ASSERT_EQ(collection->size(), 5);
    ASSERT_TRUE(max >= collection->size());

    // Check max against 10
    add_entries(5);
    ASSERT_EQ(collection->size(), 10);
    ASSERT_TRUE(max >= collection->size());
}

// Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, IsCapacityGTESizeOfEntries)
{
    // Check for initial size of 0
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
    ASSERT_TRUE(collection->size() >= collection->size());

    // Check for 1 entry
    add_entries(1);
    ASSERT_TRUE(collection->capacity() >= collection->size());
    ASSERT_EQ(collection->size(), 1);

    // Check for 5 entries
    add_entries(4);
    ASSERT_TRUE(collection->capacity() >= collection->size());
    ASSERT_EQ(collection->size(), 5);

    // Check for 10 entries
    add_entries(5);
    ASSERT_TRUE(collection->capacity() >= collection->size());
    ASSERT_EQ(collection->size(), 10);

}

// Create a test to verify resizing increases the collection
TEST_F(CollectionTest, DidResizeIncrease)
{
    // Get starting size
    int start = collection->size();

    // Resize by 1
    collection->resize(start + 1);

    // Verify increase
    ASSERT_TRUE(collection->size() > start);
}

// Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, DidResizeDecrease)
{
    // Get starting size
    int start = collection->size();

    // Cannot have negative vector. If 0, add 1
    if (start == 0) {
        add_entries(1);
        start = collection->size();
    }

    // Resize by 1
    collection->resize(start - 1);

    // Verify decrease
    ASSERT_TRUE(collection->size() < start);
}

// Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, VerifyResizeDecreaseToZero)
{
    // Get starting size
    int start = collection->size();

    // Resize our start to equal 0
    collection->resize(start - start);

    ASSERT_EQ(collection->size(), 0);
    ASSERT_TRUE(collection->empty());
}

// Create a test to verify clear erases the collection
TEST_F(CollectionTest, VerifyClearErasesAll)
{
    // Get starting size
    int start = collection->size();

    // First ensure that the collection is not already empty
    if (start == 0) {
        add_entries(5);
    }

    // Verify clear works
    collection->clear();
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, CanEraseCollectionBeginToEnd)
{
    // Get starting size
    int start = collection->size();

    // First ensure that the collection is not already empty
    if (start == 0) {
        add_entries(5);
    }

    // Start and check erase
    collection->erase(collection->begin(), collection->end());

    // Check for empty
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

}

// Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, VerifyReserveIncreasesCapacityOnly)
{
    // Get starting size
    int startSize = collection->size();
    // Get starting capacity
    int startCap = collection->capacity();

    // Check that they are not equal
    ASSERT_FALSE(startSize == collection->max_size());

    // Make the reserve
    collection->reserve(startCap + 1);

    // Check that the size is the same and the capacity has increased
    EXPECT_EQ(collection->size(), startSize);
    ASSERT_TRUE(collection->capacity() > startCap);
}

// Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, VerifyOutOfRangeExceptionThrown)
{
    // Get starting size
    int start = collection->size();

    // Check that statement is thrown
    ASSERT_THROW(collection->at(start + 1), std::out_of_range);
}

// Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
// Positive Test
TEST_F(CollectionTest, VerifyPushIncreasesLength)
{
    // Get starting size
    int start = collection->size();

    // Add element
    collection->push_back(1);

    ASSERT_TRUE(collection->size() > start);
}
// Negative Test
TEST_F(CollectionTest, VerifyExceptionWithNegativeLength)
{
    // Check that an exception is thrown when we reserve with a negative integer
    ASSERT_THROW(collection->reserve(-1), std::length_error);
}